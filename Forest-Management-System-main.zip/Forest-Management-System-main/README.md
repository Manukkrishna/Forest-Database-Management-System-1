# Forest-Management-System
    Forest Management System is used to find the index of flora and fauna present in the forest. It is represented with the help of database that we have created.
    It is based on sustainable Development Goal 15 (SDG 15 or Global Goal 15) is about "Life on land".
    It contains entities like Amphibians, Aves, Mammals, Angiosperm and Gymnosperm.
    They all have their attributes like Common name, scientific name, population trend, Red list data.
